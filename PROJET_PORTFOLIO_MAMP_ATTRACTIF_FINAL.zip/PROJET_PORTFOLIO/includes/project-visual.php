<?php
declare(strict_types=1);

/** A lightweight, purpose-made visual treatment for each case-study card. */
function project_visual(array $project, string $size = 'card'): void
{
    $accent = $project['accent'] ?? 'violet';
    $imageUrl = trim((string) ($project['image_url'] ?? ''));
    if ($imageUrl !== ''): ?>
      <div class="project-visual project-visual--image project-visual--<?= e($size) ?>" role="img" aria-label="Capture du projet <?= e($project['title']) ?>">
        <img src="<?= e($imageUrl) ?>" alt="Capture du projet <?= e($project['title']) ?>" loading="lazy">
        <div class="visual-caption"><span><?= e($project['label']) ?></span><strong><?= e($project['title']) ?></strong></div>
      </div>
      <?php return;
    endif;
    ?>
    <div class="project-visual project-visual--placeholder project-visual--<?= e($size) ?>" role="img" aria-label="Capture du projet <?= e($project['title']) ?> à ajouter">
      <div class="capture-placeholder">
        <span class="capture-placeholder-icon" aria-hidden="true">↗</span>
        <span class="capture-placeholder-label">Capture du projet</span>
        <strong><?= e($project['title']) ?></strong>
        <small>Ajoutez une vraie capture depuis l’espace administrateur.</small>
      </div>
      <div class="visual-caption"><span><?= e($project['label']) ?></span><strong><?= e($project['title']) ?></strong></div>
    </div>
    <?php
}
