<?php
declare(strict_types=1);
require __DIR__ . '/includes/site.php';
site_header('Contact et devis', 'Contactez Michael AKAKPOSSE pour discuter de votre site vitrine, application web ou projet e-commerce.', '/contact.php');
?>
<section class="contact-page"><div class="shell contact-layout"><div class="contact-intro" data-reveal><p class="eyebrow"><span></span> Contact & devis</p><h1>Votre projet commence par une <em>bonne conversation.</em></h1><p>Décrivez ce que vous avez en tête. Je vous répondrai sous 24 à 48 heures ouvrées avec les prochaines étapes les plus utiles.</p><div class="contact-direct"><a href="mailto:<?= e(config('email')) ?>"><span>Écrire un e-mail</span><strong><?= e(config('email')) ?></strong></a><a href="<?= e(whatsapp_url()) ?>" target="_blank" rel="noopener noreferrer"><span>Échanger rapidement</span><strong>WhatsApp <i>↗</i></strong></a></div><div class="contact-mini-proof"><span>✓</span><p>Une demande claire, aucune obligation.<br>Vos informations restent confidentielles.</p></div></div><div class="contact-card" data-reveal data-delay="100"><h2>Parlons de votre besoin</h2><p>Les champs marqués d’un astérisque sont indispensables.</p><?php require __DIR__ . '/includes/contact-form.php'; ?></div></div></section>
<?php site_footer(); ?>
