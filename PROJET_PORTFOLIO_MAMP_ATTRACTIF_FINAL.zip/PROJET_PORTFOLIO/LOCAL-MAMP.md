# Portfolio — configuration locale MAMP

## Adresse
Si le projet est placé dans `/Applications/MAMP/htdocs/PROJET_PORTFOLIO`, ouvrez :
`http://localhost:8888/PROJET_PORTFOLIO/`

Administration :
- `http://localhost:8888/PROJET_PORTFOLIO/admin/`
- secours : `http://localhost:8888/PROJET_PORTFOLIO/admin.php`
- première création du compte : `http://localhost:8888/PROJET_PORTFOLIO/admin/setup.php`

## MySQL MAMP
- hôte : `127.0.0.1`
- port : `8889`
- utilisateur : `root`
- mot de passe : `root`
- base : `PORTFOLIO`

Importez `PORTFOLIO.sql` dans phpMyAdmin MAMP si la base n’existe pas encore.

## Photo personnelle
Ajoutez votre vraie photo dans `assets/images/profile.jpg`. Le site l'utilisera automatiquement à la place du placeholder.

## Captures de projets
Depuis **Administration → Mes projets**, importez une capture JPG/PNG/WebP de chaque réalisation. Le site utilise alors automatiquement la vraie image.
